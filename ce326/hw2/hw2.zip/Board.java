package ce326.hw2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Board {
    private int rows;
    private int columns;
    private int init_energy;
    private int shield = 0;
    private String[] alphabet = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    private Position[][] gameboard = {};
    private int cellsLeft;
    private static final String RESET = "\u001b[0m";
    private static final String RED = "\u001b[31m";
    private static final String GREEN = "\u001b[32m";
    private static final String YELLOW = "\u001b[33m";
    private static final String BLUE = "\u001b[34m";

    public Board(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        this.gameboard = new Position[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                this.gameboard[i][j] = new Position(i, j, false); 
            }
        }
    }

    public void AddToBoard(int row, int column, BoardElement ObjToAdd) {
        this.gameboard[row][column].addContent(ObjToAdd);
    }

    public Position getCell(int row, int column) {
       return(this.gameboard[row][column]);
    }

    public void SetEnergy(int energy) {
        this.init_energy = energy;
    }

    public void SetShield(int shield) {
        this.shield = shield;
    }

    public int GetRows() {
        return this.rows;
    }

    public int GetColumns() {
        return this.columns;
    }

    public int GetEnergy() {
        return this.init_energy;
    }

    public int GetShield() {
        return this.shield;
    }

    public void setCellsRemaining(Board gameBoard) {
        int obsCount = 0;
        int count = 0;
        for (int i = 0; i < GetRows(); i++) {
            for (int j = 0; j < GetColumns(); j++) {
                if (getPosition(i, j).isObstacle()) {
                    obsCount++;
                }

                if (!getPosition(i, j).hasVisited()) {
                    count++;
                }
            }
        }

        this.cellsLeft = count - obsCount - 1;
    }

    public int getCellsRemaining() {
        return this.cellsLeft;
    }

    public void increaseCellsLeft() {
        this.cellsLeft++;
    }

    public void decreaseCellsLeft() {
        this.cellsLeft--;
    }
 
    public void PrintBoard() {
        for (int i = -1; i < this.rows ; i++) {
            if (i == -1) {
                System.out.print("  ");
                for (int j = 0; j < this.columns; j++) {
                    System.out.print(j+1 + " ");
                }
                System.out.println();
                continue;
            }
            System.out.print(this.alphabet[i] + " ");
            for (int j = 0; j < this.columns; j++) {
                Position currentPos = this.gameboard[i][j];
                String symbolToPrint = "-"; 

                if (currentPos.isObstacle()) {
                    symbolToPrint = "#";
                } 
                else if (!currentPos.getAllContents().isEmpty()) {
                    symbolToPrint = currentPos.getAllContents().get(0).getSymbol();
                    
                    for (BoardElement element : currentPos.getAllContents()) {
                        String sym = element.getSymbol();
                        if (sym.startsWith("@")) {
                            symbolToPrint = sym;
                        }
                        if (sym.equals("X")) {
                            symbolToPrint = sym;
                            break; 
                        }
                    }
                } 
                else if (currentPos.hasVisited()) {
                    symbolToPrint = " ";
                }

                if (symbolToPrint.length() > 1) {
                    char content = symbolToPrint.charAt(0);
                    char colorChar = symbolToPrint.charAt(1);
                    String colorCode = switch (colorChar) {
                        case 'b' -> BLUE;
                        case 'g' -> GREEN;
                        case 'r' -> RED;
                        case 'y' -> YELLOW;
                        default -> RESET;
                    };
                    System.out.print(colorCode + content + RESET + " ");
                } else {
                    System.out.print(symbolToPrint + " ");
                }
            }
            System.out.println();
        }
    }

    public boolean moveActor(String userInput) {
        int row, column;
        Position newPosition;
        int[] actorPos = getActorPosition();

        row = rowMatcher(userInput.toLowerCase().charAt(0));
        column = Character.getNumericValue(userInput.charAt(1)) - 1;

        if ((row >= this.rows) || (row < 0)) {
            System.out.println("Invalid number of rows! Try again.");
            return false;
        }
        if ((column >= this.columns) || (column < 0)) {
            System.out.println("Invalid number of columns! Try again.");
            return false;
        }

        newPosition = this.gameboard[row][column];
        if(!isValidMove(newPosition)){
            return false;
        }

        Position oldPosition = this.gameboard[actorPos[0]][actorPos[1]];
        oldPosition.setVisited(true);
        Actor theActor = null;
        Boolean justConsumed = false;
        for (BoardElement element : oldPosition.getAllContents()) {
            if (element instanceof Actor actor) {
                theActor = actor;
                break;
            }
        }

        if(theActor != null) {

            oldPosition.removeContent(theActor);
            newPosition.addContent(theActor);
            if (newPosition.hasVisited()) {
                theActor.setPosition(row, column);  
            }
            else {
                newPosition.setVisited(true);
                decreaseCellsLeft();
                theActor.setPosition(row, column);  
            }
        }
        else {
            System.out.println("Error with the Actor's movement, try again.");
            return false;
        }
        
        for (BoardElement element : newPosition.getAllContents()) {
            if (element == null) {
                break;
            }

            if (element instanceof Food item) {
                theActor.addEnergy(item.gainEnergy());
                newPosition.removeContent(item);
            }
            if (element instanceof MagicShield item) {
                theActor.addShield(item.gainShield());
                newPosition.removeContent(item);
                justConsumed = true;
            }

            if (element instanceof Ghost ghost) {
                if(theActor.getShield() > 0) {
                    newPosition.removeContent(ghost);
                }
                else {
                    theActor.removeEnergy(theActor.getEnergy());
                }
            }
        }
        if (theActor.getShield() > 0 && !justConsumed) {
            theActor.removeShield(1);
        } else {
            theActor.removeEnergy(1);
            justConsumed = false;
        }

        return true;
    }

    public void moveGhost(Ghost ghost, int newRow, int newColumn) {
        Position oldPosition = this.gameboard[ghost.getRow()][ghost.getColumn()];
        Position newPosition = this.gameboard[newRow][newColumn];

        oldPosition.removeContent(ghost);
        newPosition.addContent(ghost);

        ghost.setPosition(newRow, newColumn);
    }

    private boolean isValidMove(Position newPosition) {
        int[] actorPos;
        actorPos = getActorPosition();

        if (newPosition.isObstacle()) {
            System.out.println("You can't go to an obstacle! Try again.");
            return false;
        }

        int rowabs = Math.abs(newPosition.getRow() - actorPos[0]);
        int colabs = Math.abs(newPosition.getColumn() - actorPos[1]);

        if ((rowabs > 1) && (rowabs != this.rows - 1)) {
            System.out.println("Oops thats too far! Try again.");
            return false;
        }
        
        if ((colabs > 1) && (colabs != this.columns - 1)) {
            System.out.println("Oops thats too far! Try again.");
            return false;
        }
        
        return true;
    }

    private int rowMatcher(char rowChar) {
        int row = 0;

        for (char c = 'a' ; c < rowChar ; c++) {
            row++;
        }
        return row;
    }

    public char rowMatcher(int rowInt){
        return (char) (rowInt + 'A');
    }

    private int[] getActorPosition() {
        int[] position = new int[2];
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.columns; j++) {
                Position currentPos = this.gameboard[i][j];
                if (!currentPos.getAllContents().isEmpty()) {
                    for (BoardElement element : currentPos.getAllContents()) {
                        if (element instanceof Actor) {
                            position[0] = i;
                            position[1] = j;
                            return position;
                        }
                    }
                }
            }
        }
        return null; 
    }

    public int getActorCurrentEnergy() {
        int[] pos = getActorPosition();
        
        if (pos == null) {
            return 0; 
        }

        Position currentPos = this.gameboard[pos[0]][pos[1]];
        for (BoardElement element : currentPos.getAllContents()) {
            if (element instanceof Actor actor) {
                return actor.getEnergy();
            }
        }
        
        return 0; 
    }

    public int getActorCurrentShield() {
        int[] pos = getActorPosition();
        
        if (pos == null) {
            return 0; 
        }

        Position currentPos = this.gameboard[pos[0]][pos[1]];
        for (BoardElement element : currentPos.getAllContents()) {
            if (element instanceof Actor actor) {
                return actor.getShield();
            }
        }
        
        return 0; 
    }

    public void printDebugInfo() {
        int [][] debugGrid = new int[this.rows][this.columns];
        int[] actorPosition = getActorPosition();
        for(int i = 0; i < this.rows; i++){
            for (int j = 0; j < this.columns; j++){
                if (this.gameboard[i][j].isObstacle()) {
                    debugGrid[i][j] = -1;
                } else {
                    debugGrid[i][j] = 100;
                }  
            }
        }

        Queue<int[]> queue = new LinkedList<>();
        queue.add(actorPosition);
        debugGrid[actorPosition[0]][actorPosition[1]] = 0;

        int[] x = {0, 0, 1, -1}; // right, left, down, up
        int[] y = {1, -1, 0, 0};

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            for (int i = 0; i < 4; i++) {
                int newRow = current[0] + x[i];
                int newCol = current[1] + y[i];

                if (newRow >= this.rows) { newRow = 0; }
                if (newRow < 0) { newRow = this.rows - 1; }
                if (newCol >= this.columns) { newCol = 0; }
                if (newCol < 0) { newCol = this.columns - 1; }

                if (debugGrid[newRow][newCol] != -1 && debugGrid[newRow][newCol] > debugGrid[current[0]][current[1]] + 1) {
                    debugGrid[newRow][newCol] = debugGrid[current[0]][current[1]] + 1;
                    queue.add(new int[]{newRow, newCol});
                }
            }
        }

        boolean[][] ghostReachable = getGhostReachableCells();

        for (int i = -1; i < this.rows; i++) {
            if (i == -1) {
                System.err.print("   ");
                for (int j = 0; j < this.columns; j++) {
                    System.err.print(j + 1 + "  ");
                }
                System.err.println();
                System.err.print(" ");
                for (int j = 0; j < this.columns; j++) {
                    System.err.print("---");
                }
                System.err.println();
                continue;
            }
            System.err.print(this.alphabet[i] + "  ");
            for (int j = 0; j < this.columns; j++) {
                
                if (!this.gameboard[i][j].isObstacle() && !ghostReachable[i][j]) {
                    System.err.print("?  ");
                } 
                else {
                    switch (debugGrid[i][j]) {
                        case -1 -> System.err.print("#  ");
                        case 100 -> System.err.print("U  "); //Unreachable by the Actor
                        default -> System.err.print(debugGrid[i][j] + "  ");
                    }
                }
            }
            System.err.println();
        }
    }
    
    public boolean[][] getGhostReachableCells() {
        boolean[][] reachable = new boolean[this.rows][this.columns];
        Queue<int[]> queue = new LinkedList<>();

        for (Ghost ghost : getGhosts()) {
            queue.add(new int[]{ghost.getRow(), ghost.getColumn()});
            reachable[ghost.getRow()][ghost.getColumn()] = true;
        }

        int[] dRow = {0, 0, 1, -1}; 
        int[] dCol = {1, -1, 0, 0};

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            
            for (int i = 0; i < 4; i++) {
                int newRow = current[0] + dRow[i];
                int newCol = current[1] + dCol[i];

                if (newRow >= this.rows) { newRow = 0; }
                if (newRow < 0) { newRow = this.rows - 1; }
                if (newCol >= this.columns) { newCol = 0; }
                if (newCol < 0) { newCol = this.columns - 1; }

                if (!this.gameboard[newRow][newCol].isObstacle() && !reachable[newRow][newCol]) {
                    reachable[newRow][newCol] = true;
                    queue.add(new int[]{newRow, newCol});
                }
            }
        }
        return reachable;
    }

    public ArrayList<Ghost>getGhosts(){
        ArrayList<Ghost> ghosts = new ArrayList<>();

        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.columns; j++) {
                Position currentPos = this.gameboard[i][j];
                if (!currentPos.getAllContents().isEmpty()) {
                    for (BoardElement element : currentPos.getAllContents()) {
                        if (element instanceof Ghost) {
                            ghosts.add((Ghost) element);
                        }
                    }
                }
            }
        }
        return ghosts;
    }

    public Actor getActor() {
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.columns; j++) {
                Position currentPos = this.gameboard[i][j];
                if (!currentPos.getAllContents().isEmpty()) {
                    for (BoardElement element : currentPos.getAllContents()) {
                        if (element instanceof Actor) {
                            return (Actor) element;
                        }
                    }
                }
            }
        }
        return null; 
    }

    public Board copyBoard() {
        Board clonedBoard = new Board(this.rows, this.columns);
        clonedBoard.SetEnergy(this.init_energy);
        clonedBoard.SetShield(this.shield);

        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.columns; j++) {
                Position currentPos = this.gameboard[i][j];
                Position clonedPos = new Position(i, j, currentPos.isObstacle());
                clonedPos.setVisited(currentPos.hasVisited());
                for (BoardElement element : currentPos.getAllContents()) {
                    switch (element) {
                        case Actor actor -> {
                            Actor clonedActor = new Actor(actor.getRow(), actor.getColumn(), actor.getEnergy());
                            clonedActor.addShield(actor.getShield());
                            clonedPos.addContent(clonedActor);
                        }
                        case Ghost ghost -> {
                            Ghost clonedGhost = new Ghost(ghost.getRow(), ghost.getColumn(), ghost.getSymbol());
                            clonedPos.addContent(clonedGhost);
                        }
                        case Food food -> {
                            Food clonedFood = new Food(food.getRow(), food.getColumn(), food.getSymbol());
                            clonedPos.addContent(clonedFood);
                        }
                        case MagicShield Shield -> {
                            MagicShield clonedShield = new MagicShield(Shield.getRow(), Shield.getColumn(), Shield.getSymbol());
                            clonedPos.addContent(clonedShield);
                        }
                        default -> {}
                    }
                }
                clonedBoard.gameboard[i][j] = clonedPos;
            }
        }
        return clonedBoard;
    }

    public Position getPosition(int row, int column) {
        return this.gameboard[row][column];
    }
}
